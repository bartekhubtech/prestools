<?php

/*
 * 2007-2015 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 *  @author PrestaShop SA <contact@prestashop.com>
 *  @copyright  2007-2015 PrestaShop SA
 *  @version  Release: $Revision: 13573 $
 *  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
 */

class AdminPrestoolsSuiteController extends ModuleAdminController
{
	public function __construct()
	{ error_reporting(E_ALL);
	  $this->name = 'prestoolssuite';
	  parent::__construct();
  
	}
	
	private function checkBom($session)
	{ 	if($session)
		{   $file = @fopen("approve.php", "r"); 
			$bom = fread($file, 3); 
			if ($bom == b"\xEF\xBB\xBF") 
			{ echo '<script type="text/javascript">
					alert(\'BOM header found! Use another text editor!\');
				</script>';
			  exit;
			}
		} 
	}
	
	private function get_seed()
	{ $key = Configuration::get('PS_PRESTOOLS_KEY');
	  if(!$key)
      { $key = "";
        $len = 30;
	    $rawkey = openssl_random_pseudo_bytes($len);
	    for($i=0; $i<$len; $i++) /* make sure that all bytes have ascii value between 32 and 126 */
		{ $x = ord($rawkey[$i]);
		  if($x > 126) $x -= 126;
		  if($x <32) $x += 32;
		  if($x==97) $x= 42; /* remove slashes, ampersand and quotes */
		  if($x==32) $x= 63;
		  if($x==34) $x= 37;
		  if($x==39) $x= 68;
		  if($x==38) $x= 72;
		  $key .= chr($x);
		}
		Configuration::updateValue('PS_PRESTOOLS_KEY', $key);
	  }
	  return @date("mY").$key;
	}
	
	public function setMedia($isNewTheme = false)
	{ $musername = Configuration::get('PRESTOOLSSUITE_USERNAME');
	  $mpassword = Configuration::get('PRESTOOLSSUITE_PASSW');
	  $mdirectory = Configuration::get('PRESTOOLSSUITE_DIR');
	  if (!file_exists($mdirectory."/settings1.php"))
	  { // echo "Settings file could not be loaded. Please check the Prestools subdirectory!";
		// SetMedia is not the right place to display a message. It is for including js and css files 
		// Yet to find out how to display an error message here.
		return parent::setMedia();
	  }
	  $userkey = preg_replace('/[^a-zA-Z0-9]/','', $musername);
      $seed = $this->get_seed();
      $encseed = hash('sha256', $seed.$mpassword);
	  $phpath = dirname($_SERVER["SCRIPT_NAME"])."/".$mdirectory;
	  $encseed2 = stripslashes(stripslashes(stripslashes(convert_uuencode(base64_encode($encseed)))));
	  setcookie("tripleedit".$userkey, $encseed2,  time()+3600*24*365, $phpath);

	  if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') 
		  $prefix = "https://";
	  else 
		  $prefix = "http://";
	  $newpath = $prefix.$_SERVER['HTTP_HOST'].dirname($_SERVER["SCRIPT_NAME"])."/".$mdirectory."/product-edit.php";
	  if(1)
	  { header("Location: ".$newpath);
	    exit;
	  }
	  return parent::setMedia($isNewTheme);
	}
	
	public function initContent()
	{ // $this-> renderView();
	  return parent::initContent();
	}
	
	public function renderView()
	{	
	   if(!($config = $this->loadObject()))
	   { 
            return;
        } 
//		$this->context->smarty->createTemplate('form.tpl', $this->context->smarty);
		$this->base_tpl_view = 'form.tpl';
		        $this->tpl_view_vars = array(
            'username' => "Johny",
            'password' => "geheim",
            'hauteur' => "90283"
            );
//$this->module->display(_PS_MODULE_DIR_.$this->module->name.DIRECTORY_SEPARATOR.$this->module->name.'.php', 'form.tpl'); 
		return parent::renderView();
	}
}

